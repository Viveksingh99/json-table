import React, { Component } from 'react';
import './App.css';
import DataTable from './DataTable';

class App extends Component {
  render() {
    return (
      <div>
      <DataTable/>
      </div>
    );
  }
}

export default App;
